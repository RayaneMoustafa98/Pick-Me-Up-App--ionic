import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OffersServiceService, Offer } from '../services/offers-service.service';

@Component({
  selector: 'app-passenger',
  templateUrl: './passenger.page.html',
  styleUrls: ['./passenger.page.scss'],
})
export class PassengerPage implements OnInit {

  offers: Offer[];

  constructor(private router: Router, private service: OffersServiceService) { }

  ngOnInit() {
    this.service.getAllOffers().subscribe(response => {
      this.offers = response;
      console.log(this.offers);
    });



  }
  public navigateToPostedOffersPage(){
    this.router.navigate(['posted-offerspage']);
  }

}
