import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DriverORpassengerPageRoutingModule } from './driver-orpassenger-routing.module';

import { DriverORpassengerPage } from './driver-orpassenger.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DriverORpassengerPageRoutingModule
  ],
  declarations: [DriverORpassengerPage]
})
export class DriverORpassengerPageModule {}
