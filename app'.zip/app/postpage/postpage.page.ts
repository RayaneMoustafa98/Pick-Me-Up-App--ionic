import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-postpage',
  templateUrl: './postpage.page.html',
  styleUrls: ['./postpage.page.scss'],
})
export class PostpagePage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  public navigateToMainscreen(){
    this.router.navigate(['mainscreen']);
  }
}
