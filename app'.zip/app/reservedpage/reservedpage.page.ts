import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reservedpage',
  templateUrl: './reservedpage.page.html',
  styleUrls: ['./reservedpage.page.scss'],
})
export class ReservedpagePage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  public navigateToMainscreen(){
    this.router.navigate(['mainscreen']);
  }
}
