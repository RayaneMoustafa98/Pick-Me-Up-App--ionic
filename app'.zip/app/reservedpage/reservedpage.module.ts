import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ReservedpagePageRoutingModule } from './reservedpage-routing.module';

import { ReservedpagePage } from './reservedpage.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReservedpagePageRoutingModule
  ],
  declarations: [ReservedpagePage]
})
export class ReservedpagePageModule {}
