import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OffersServiceService, Offer } from '../services/offers-service.service';

@Component({
  selector: 'app-driver-page',
  templateUrl: './driver-page.page.html',
  styleUrls: ['./driver-page.page.scss'],
})
export class DriverPagePage implements OnInit {

  offers: Offer[];

  constructor(private router: Router, private service: OffersServiceService) { }

  ngOnInit() {
    this.service.getAllOffers().subscribe(response => {
      this.offers = response;
      console.log(this.offers);
    });



  }
  public navigateToPostPage(){
    this.router.navigate(['postpage']);
  }

}
