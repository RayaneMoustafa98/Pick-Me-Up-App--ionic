import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DriverPagePage } from './driver-page.page';

const routes: Routes = [
  {
    path: '',
    component: DriverPagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DriverPagePageRoutingModule {}
