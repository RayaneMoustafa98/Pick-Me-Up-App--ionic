import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


export interface users{

  id: string,
  full_name: string,
  email: string,
  phonenb: string,
  password: string


}
@Injectable({
  providedIn: 'root'
})
export class SignupService {

  private url = "http://localhost/PickMeUpApp/app_apis/";

  constructor(private http : HttpClient) { }

  getAllOffers(){
    return this.http.get<[users]>(this.url + "signup.php");
  }
}
