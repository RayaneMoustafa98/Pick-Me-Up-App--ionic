import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


export interface Offer{

  id: string,
  full_name: string,
  location: string,
  destination: string,
  time: string,
  seats_available: string,
  hasLicense: string


}
@Injectable({
  providedIn: 'root'
})
export class OffersServiceService {

  private url = "http://localhost/PickMeUpApp/app_apis/";

  constructor(private http : HttpClient) { }

  getAllOffers(){
    return this.http.get<[Offer]>(this.url + "getOffers.php");
  }
}
