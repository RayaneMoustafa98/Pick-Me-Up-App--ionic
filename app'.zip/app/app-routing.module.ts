import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [

  {
    path: '',
    redirectTo: 'mainscreen',
    pathMatch: 'full'
  },
  {
    path: 'mainscreen',
    loadChildren: () => import('./mainscreen/mainscreen.module').then( m => m.MainscreenPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'forgot-password',
    loadChildren: () => import('./forgot-password/forgot-password.module').then( m => m.ForgotPasswordPageModule)
  },
  {
    path: 'sign-up',
    loadChildren: () => import('./sign-up/sign-up.module').then( m => m.SignUpPageModule)
  },
  {
    path: 'driver-orpassenger',
    loadChildren: () => import('./driver-orpassenger/driver-orpassenger.module').then( m => m.DriverORpassengerPageModule)
  },
  {
    path: 'driver-page',
    loadChildren: () => import('./driver-page/driver-page.module').then( m => m.DriverPagePageModule)
  },
  {
    path: 'passenger-page',
    loadChildren: () => import('./passenger/passenger.module').then( m => m.PassengerPageModule)
  },
  {
    path: 'postpage',
    loadChildren: () => import('./postpage/postpage.module').then( m => m.PostpagePageModule)
  },
  {
    path: 'services',
    loadChildren: () => import('src/app/services/offers-service.service')
  },
  {
    path: 'passenger',
    loadChildren: () => import('./passenger/passenger.module').then( m => m.PassengerPageModule)
  },
  {
    path: 'posted-offerspage',
    loadChildren: () => import('./posted-offerspage/posted-offerspage.module').then( m => m.PostedOfferspagePageModule)
  },
  {
    path: 'reservedpage',
    loadChildren: () => import('./reservedpage/reservedpage.module').then( m => m.ReservedpagePageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
