import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PostedOfferspagePageRoutingModule } from './posted-offerspage-routing.module';

import { PostedOfferspagePage } from './posted-offerspage.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PostedOfferspagePageRoutingModule
  ],
  declarations: [PostedOfferspagePage]
})
export class PostedOfferspagePageModule {}
