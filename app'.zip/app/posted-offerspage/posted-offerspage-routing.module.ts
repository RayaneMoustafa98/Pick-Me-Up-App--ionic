import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PostedOfferspagePage } from './posted-offerspage.page';

const routes: Routes = [
  {
    path: '',
    component: PostedOfferspagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PostedOfferspagePageRoutingModule {}
